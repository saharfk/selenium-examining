import re
from selenium import webdriver
from datetime import date
import calendar

a = input('write a number\n')
b = input('write second number\n')
in1 = input('write your email:\n')
r = re.search(r'\w+@\w+\.\w+', in1)
while r == None:
    print('WRONG TRY ONE MORE TIME!!')
    in1 = input()
    r = re.search(r'\w+@\w+\.\w+', in1)

driver = webdriver.Chrome()
driver.maximize_window()
url = 'https://www.seleniumeasy.com/test/basic-first-form-demo.html'
driver.get(url)
email_F = driver.find_element_by_id('user-message')
email_F.clear()
email_F.send_keys(in1)

botton = driver.find_element_by_xpath('//button[text()="Show Message"]')
botton.click()

text_box1 = driver.find_element_by_id('sum1')
text_box1.clear()
text_box1.send_keys(a)

text_box2 = driver.find_element_by_id('sum2')
text_box2.clear()
text_box2.send_keys(b)

botton1 = driver.find_element_by_xpath('//button[text()="Get Total"]')
botton1.click()

# *******************************************
driver = webdriver.Chrome()
driver.maximize_window()
today_name = calendar.day_name[date.today().weekday()]
driver.get('https://www.seleniumeasy.com/test/basic-select-dropdown-demo.html')
el = driver.find_element_by_id('select-demo')
for option in el.find_elements_by_tag_name('option'):
    if option.text == today_name:
        option.click()
        break
